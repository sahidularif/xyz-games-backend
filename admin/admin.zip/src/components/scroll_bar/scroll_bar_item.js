import React from 'react';
import { Link } from 'react-router-dom';

class ScrollBarItem extends React.Component {
    constructor(props) {
        super(props);
    }

    render(){
        return(
            <div className="scroll-item">
                
            </div>
        )
    }
}