import React from 'react'
import { Link } from 'react-router-dom'
import Navbar_container from '../../nav/navbar_container';
const nav = () => {
  return (
    <>
        {/* <Navbar_container /> */}

          
          
    </>   
  )
}

export default nav