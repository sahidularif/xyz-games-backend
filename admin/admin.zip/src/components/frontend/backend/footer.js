import React, { Component } from 'react'

export default class footer extends Component {
  render() {
    return (
      <>
        <div className="copyright">
               <p>Copyright © XYZ-Game by <a href="" target="_blank">SAWEBSOFT</a> 2023</p>
            </div>
      </>
    )
  }
}
